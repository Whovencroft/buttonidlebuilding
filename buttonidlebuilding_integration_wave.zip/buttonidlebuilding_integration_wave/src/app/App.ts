import type { AppState } from '../core/state/AppState';
import { SaveService } from '../core/state/SaveService';
import { SceneManager } from '../core/scene/SceneManager';
import { ShellView } from '../shell/ShellView';
import { resolveSavePanelBindings, SavePanelView } from '../shell/SavePanel';
import { AudioService } from '../core/audio/AudioService';
import { AssetService } from '../core/assets/AssetService';
import { registerDefaultScenes } from './registry';

export class App {
  private readonly saveService: SaveService;
  private readonly sceneManager: SceneManager;
  private readonly shellView: ShellView;
  private readonly audioService: AudioService;
  private readonly assetService: AssetService;

  private savePanel: SavePanelView | null = null;
  private state: AppState;
  private frameHandle: number | null = null;
  private lastFrameTime = performance.now();

  public constructor() {
    this.saveService = new SaveService();
    this.sceneManager = new SceneManager();
    this.shellView = new ShellView();
    this.audioService = new AudioService({ masterVolume: 1 });
    this.assetService = new AssetService();
    this.state = this.createDefaultState();
  }

  public async init(): Promise<void> {
    await this.restoreState();
    await this.assetService.preloadMarkedAssets();

    this.bindShell();
    registerDefaultScenes(this.sceneManager, this.state);

    this.sceneManager.setActiveScene(this.state.app.activeScene);
    this.render();

    this.lastFrameTime = performance.now();
    this.startLoop();
  }

  public getState(): AppState {
    return this.state;
  }

  public replaceState(nextState: AppState): void {
    this.state = this.normalizeState(nextState);
    this.sceneManager.setActiveScene(this.state.app.activeScene);
    this.render();
  }

  public async saveNow(): Promise<void> {
    await this.saveService.save(this.state);
    this.shellView.setAutosaveStatus(`Autosave: ${new Date().toLocaleTimeString()}`);
  }

  public async hardReset(): Promise<void> {
    this.replaceState(this.createDefaultState());
    await this.saveNow();
  }

  private async restoreState(): Promise<void> {
    const loaded = await this.saveService.load();
    if (loaded) {
      this.state = this.normalizeState(loaded);
    }
  }

  private bindShell(): void {
    const saveBindings = resolveSavePanelBindings();
    if (saveBindings) {
      this.savePanel = new SavePanelView(saveBindings, this.saveService, {
        getState: () => this.getState(),
        replaceState: (nextState) => this.replaceState(nextState),
        onHardReset: () => {
          void this.hardReset();
        }
      });
      this.savePanel.attach();
    }

    window.addEventListener('beforeunload', () => {
      void this.saveNow();
    });

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        void this.saveNow();
      }
    });
  }

  private startLoop(): void {
    const step = (timestamp: number) => {
      const dt = Math.max(0, Math.min(1, (timestamp - this.lastFrameTime) / 1000));
      this.lastFrameTime = timestamp;

      this.sceneManager.update(dt);
      this.render();

      this.frameHandle = window.requestAnimationFrame(step);
    };

    this.frameHandle = window.requestAnimationFrame(step);
  }

  private render(): void {
    this.shellView.render(this.state);
    this.sceneManager.render();
  }

  private normalizeState(nextState: AppState): AppState {
    return {
      meta: {
        saveVersion: nextState.meta?.saveVersion ?? 1,
        firstRunAt: nextState.meta?.firstRunAt ?? Date.now(),
        lastPlayedAt: Date.now(),
        platform: nextState.meta?.platform ?? 'web'
      },
      app: {
        activeScene: nextState.app?.activeScene ?? 'button_idle'
      },
      scenes: {
        button_idle: {
          totalPresses: nextState.scenes?.button_idle?.totalPresses ?? 0
        },
        marble: {
          unlocked: nextState.scenes?.marble?.unlocked ?? false,
          currentLevelId: nextState.scenes?.marble?.currentLevelId ?? 'training_run',
          bestTimes: nextState.scenes?.marble?.bestTimes ?? {},
          clearedLevels: nextState.scenes?.marble?.clearedLevels ?? []
        }
      }
    };
  }

  private createDefaultState(): AppState {
    return {
      meta: {
        saveVersion: 1,
        firstRunAt: Date.now(),
        lastPlayedAt: Date.now(),
        platform: 'web'
      },
      app: {
        activeScene: 'button_idle'
      },
      scenes: {
        button_idle: {
          totalPresses: 0
        },
        marble: {
          unlocked: false,
          currentLevelId: 'training_run',
          bestTimes: {},
          clearedLevels: []
        }
      }
    };
  }
}
